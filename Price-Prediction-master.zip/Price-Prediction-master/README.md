# Price-Prediction

In this p[roject we had used beautiful soup library of python for scraping and implemented several algorithms on the scraped data and found the results are segnificant
